#!/bin/bash
export path1=/data01/backups/db_backup
date1=`date +%y%m%d_%H%M%S`
/usr/bin/find /backups/db_backup/* -type d -mtime +7 -exec rm -r {} \; 2> /dev/null
cd $path1/
mkdir $date1
USER="root"		
PASSWORD="r00t123007"	
OUTPUTDIR="$path1/$date1"
S3OUTPUTDIR="s3://props3backups/dbrds3"
MYSQLDUMP="/usr/bin/mysqldump"
MYSQL="/usr/bin/mysql"
HOST="dbrds3.cypu3wsnk6wt.us-west-2.rds.amazonaws.com"		 
databases=`$MYSQL --user=$USER --password=$PASSWORD --host=$HOST \
 -e "SHOW DATABASES;" | tr -d "| " | grep -v Database`
echo "` for db in $databases; do
    echo $db
   
        if [ "$db" = "performance_schema" ] ; then 
        $MYSQLDUMP --force --opt --single-transaction --lock-tables=false --skip-events --user=$USER --password=$PASSWORD --host=$HOST --routines \
         --databases $db | gzip > "$OUTPUTDIR/$db.gz"
         else

 $MYSQLDUMP --force --opt --single-transaction --lock-tables=false --events --user=$USER --password=$PASSWORD --host=$HOST --routines \
    --databases $db | gzip > "$OUTPUTDIR/$db.gz"
fi

done `" 

s3cmd put --recursive "$OUTPUTDIR"  "$S3OUTPUTDIR/"

rm -rf "$OUTPUTDIR"

if [ `date +%d` -eq '01' ] ; then
mv /home/som/monthly_backup_report /home/som/KALLEN_som-db1a.propertyhookup.com_54.201.99.202_Database_Backup_Report_`date +%B_%G --date="-1 day"`
fi
