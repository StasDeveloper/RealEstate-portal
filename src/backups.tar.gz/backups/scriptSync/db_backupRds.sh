#!/bin/bash
export path1=/data01/backups/db_backupSync
date1=`date +%y%m%d_%H%M%S`
/usr/bin/find /backups/db_backup/* -type d -mtime +7 -exec rm -r {} \; 2> /dev/null
cd $path1/
mkdir $date1
USER="root"		
PASSWORD="r00t123007"
OUTPUTDIR="$path1/$date1"
MYSQLDUMP="/usr/bin/mysqldump"
MYSQL="/usr/bin/mysql"
HOST="dbrds1.cypu3wsnk6wt.us-west-2.rds.amazonaws.com"		 

 $MYSQLDUMP --force --opt --single-transaction --lock-tables=false --events --user=$USER --password=$PASSWORD --host=$HOST --routines \
    --databases "bucontra_propertyhookup" > bucontra_propertyhookup_rds.sql
