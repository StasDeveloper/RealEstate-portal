#!/bin/bash
cd /var/www/html/irradii.com
git pull

