﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'it', {
	border: 'Mostra il bordo',
	noUrl: 'Inserire l\'URL del campo IFrame',
	scrolling: 'Abilita scrollbar',
	title: 'Proprietà IFrame',
	toolbar: 'IFrame'
} );
