﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'es', {
	border: 'Mostrar borde del marco',
	noUrl: 'Por favor, escriba la dirección del iframe',
	scrolling: 'Activar barras de desplazamiento',
	title: 'Propiedades de iframe',
	toolbar: 'IFrame'
} );
