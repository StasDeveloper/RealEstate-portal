﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'ka', {
	border: 'ჩარჩოს გამოჩენა',
	noUrl: 'აკრიფეთ iframe-ის URL',
	scrolling: 'გადახვევის ზოლების დაშვება',
	title: 'IFrame-ის პარამეტრები',
	toolbar: 'IFrame'
} );
