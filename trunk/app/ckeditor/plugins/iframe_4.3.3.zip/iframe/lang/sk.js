﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'sk', {
	border: 'Zobraziť rám frame-u',
	noUrl: 'Prosím, vložte URL iframe',
	scrolling: 'Povoliť skrolovanie',
	title: 'Vlastnosti IFrame',
	toolbar: 'IFrame'
} );
