﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'gl', {
	border: 'Amosar o bordo do marco',
	noUrl: 'Escriba o enderezo do iframe',
	scrolling: 'Activar as barras de desprazamento',
	title: 'Propiedades do iFrame',
	toolbar: 'IFrame'
} );
