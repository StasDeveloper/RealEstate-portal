﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'eu', {
	border: 'Markoaren ertza ikusi',
	noUrl: 'iframe-aren URLa idatzi, mesedez.',
	scrolling: 'Korritze barrak gaitu',
	title: 'IFrame-aren Propietateak',
	toolbar: 'IFrame'
} );
