﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'sl', {
	border: 'Pokaži mejo okvira',
	noUrl: 'Prosimo, vnesite iframe URL',
	scrolling: 'Omogoči scrollbars',
	title: 'IFrame Lastnosti',
	toolbar: 'IFrame'
} );
